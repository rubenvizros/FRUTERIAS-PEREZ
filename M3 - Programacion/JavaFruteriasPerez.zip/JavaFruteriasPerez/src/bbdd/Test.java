/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bbdd;

/**
 *
 * @author rubenvizros
 */

public class Test {
    public static void main(String[] args) {
        String[][] result = ConexionBD.select("SELECT product_id, name, price FROM products");
        if (result != null) {
            for (String[] row : result) {
                for (String value : row) {
                    System.out.print(value + "\t");
                }
                System.out.println();
            }
        } else {
            System.out.println("Error al ejecutar la consulta.");
        }
    }
}